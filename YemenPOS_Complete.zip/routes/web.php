<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\*;

Route::middleware('web')->group(function(){
    Route::get('/', [DashboardController::class,'index'])->name('dashboard');
    Route::get('/pos', [PosController::class,'index'])->name('pos');
    Route::get('/pos/returns', [PosController::class,'returns'])->name('pos.returns');
    Route::resource('products', ProductController::class);
    Route::resource('categories', CategoryController::class);
    Route::resource('branches', BranchController::class);
    Route::resource('purchases', PurchaseController::class);
    Route::resource('customers', CustomerController::class);
    Route::resource('suppliers', SupplierController::class);
    Route::get('/reports/sales', [ReportController::class,'sales'])->name('reports.sales');
    Route::get('/reports/inventory', [ReportController::class,'inventory'])->name('reports.inventory');
    Route::get('/inventory/low', [InventoryController::class,'lowStock'])->name('inventory.low');
});
